from django.shortcuts import render

# Create your views here.


#Createyourviewshere.

def index(request):
    return render(request,'index.html')