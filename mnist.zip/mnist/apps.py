from django.apps import AppConfig


class MnistConfig(AppConfig):
    name = 'mnist'
