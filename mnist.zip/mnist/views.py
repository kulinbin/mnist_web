from django.http import JsonResponse
from django.shortcuts import render
import base64
from PIL import Image
from applicate_model import distinguish as sb
import io


# Create your views here.

def mnist(request):
    b=0
    if request.is_ajax():
        # 获取其中的某个键的值
        img_not_decode = request.GET.getlist('img')
        img_decode = base64.urlsafe_b64decode(img_not_decode[0])
        image = io.BytesIO(img_decode)
        img = Image.open(image)
        img = img.resize((28, 28), Image.ANTIALIAS)
        myimage = img.convert('L')
        tv = list(myimage.getdata())  # 获取图片像素值
        tva = [(255 - x) * 1.0 / 255.0 for x in tv]  # 转换像素范围到[0 1], 0是纯白 1是纯黑
        tva = [tva]
        a = sb(tva)
        res = str(a)
        response = JsonResponse({"res": res})
        return response

    return render(request,'mnist.html')
